// APP PROFISSIONAL DE AGENDAMENTO DE MASSOTERAPIA
// Stack: React + Firebase (Banco de Dados + Auth)

import React, { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

// 🔥 IMPORTAR FIREBASE (você precisa configurar)
import { initializeApp } from "firebase/app";
import { getFirestore, collection, addDoc, getDocs } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "SUA_API_KEY",
  authDomain: "SEU_DOMINIO",
  projectId: "SEU_PROJECT_ID",
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const services = [
  { name: "Massagem Relaxante", price: 100 },
  { name: "Massagem Terapêutica", price: 150 },
  { name: "Drenagem Linfática", price: 180 }
];

export default function App() {
  const [service, setService] = useState(null);
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [appointments, setAppointments] = useState([]);

  // 🔥 SALVAR AGENDAMENTO
  const saveAppointment = async () => {
    if (!service || !date || !time || !name) return alert("Preencha tudo");

    await addDoc(collection(db, "agendamentos"), {
      name,
      phone,
      service: service.name,
      price: service.price,
      date,
      time,
      address
    });

    alert("Agendamento salvo!");
    loadAppointments();
  };

  // 🔥 LISTAR AGENDAMENTOS (ADMIN)
  const loadAppointments = async () => {
    const querySnapshot = await getDocs(collection(db, "agendamentos"));
    const list = [];
    querySnapshot.forEach((doc) => list.push(doc.data()));
    setAppointments(list);
  };

  useEffect(() => {
    loadAppointments();
  }, []);

  const whatsappMessage = `Olá, sou ${name}. Quero agendar ${service?.name} dia ${date} às ${time}`;
  const whatsappLink = `https://wa.me/55${phone}?text=${encodeURIComponent(whatsappMessage)}`;

  return (
    <div className="p-6 grid gap-6 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold">Seu Spa - Agendamento</h1>

      {/* CLIENTE */}
      <Card>
        <CardContent className="p-4">
          <h2>Cliente</h2>
          <Input placeholder="Nome" onChange={(e) => setName(e.target.value)} />
          <Input placeholder="WhatsApp" className="mt-2" onChange={(e) => setPhone(e.target.value)} />
        </CardContent>
      </Card>

      {/* SERVIÇO */}
      <Card>
        <CardContent className="p-4">
          <h2>Serviços</h2>
          {services.map((s) => (
            <Button key={s.name} onClick={() => setService(s)} className="m-1">
              {s.name} - R$ {s.price}
            </Button>
          ))}
        </CardContent>
      </Card>

      {/* DATA */}
      <Card>
        <CardContent className="p-4">
          <h2>Data e Hora</h2>
          <Input type="date" onChange={(e) => setDate(e.target.value)} />
          <Input type="time" className="mt-2" onChange={(e) => setTime(e.target.value)} />
        </CardContent>
      </Card>

      {/* ENDEREÇO */}
      <Card>
        <CardContent className="p-4">
          <h2>Endereço</h2>
          <Input placeholder="Digite o endereço" onChange={(e) => setAddress(e.target.value)} />
        </CardContent>
      </Card>

      {/* AÇÕES */}
      <div className="flex gap-2">
        <Button onClick={saveAppointment}>Salvar Agendamento</Button>
        <a href={whatsappLink} target="_blank">
          <Button>WhatsApp</Button>
        </a>
      </div>

      {/* ADMIN */}
      <Card>
        <CardContent className="p-4">
          <h2>Painel Admin</h2>
          {appointments.map((a, i) => (
            <div key={i} className="border p-2 mt-2">
              <p>{a.name}</p>
              <p>{a.service}</p>
              <p>{a.date} - {a.time}</p>
              <p>R$ {a.price}</p>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
